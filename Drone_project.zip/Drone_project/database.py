"""
database.py
Fixed and simplified database module for the Starlight Command project.
Make sure to overwrite your local `database.py` with the contents below.
"""

import sqlite3
import threading
import os
from datetime import datetime

# Paths
BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, 'fleet_command.db')
# DB_PATH = os.path.join(BASE_DIR)
_SCHEMA_PATH = os.path.join(BASE_DIR, 'schema.sql')

# Thread-safety
# _conn_lock = threading.Lock()
DB_PATH = "my_database.db"

# ye variableDB_PATH = "my_database.db"

# ye variable ek hi connection store karega
conn = None  

def get_db_connection():
    global conn
    if conn is None:  # agar connection pehle se nahi bana
        conn = sqlite3.connect(DB_PATH)  # naya connection banao
    return conn  # ham ek hi connection store karega
# conn = None  

# def get_db_connection():
#     global conn
#     if conn is None:  # agar connection pehle se nahi bana
#         conn = sqlite3.connect(DB_PATH)  # naya connection banao
#     return conn  # ham


def close_db_connection():
    """Close the shared database connection if open."""
    global conn
    if conn is not None:
        conn.close()
        conn = None


def create_tables():
    """Execute the schema.sql script to create tables if they don't exist."""
    conn = get_db_connection()
    with open(_SCHEMA_PATH, 'r', encoding='utf-8') as f:
        schema = f.read()
    cur = conn.cursor()
    cur.executescript(schema)
    conn.commit()


# --- Drone & Planet operations ---

def add_drone(call_sign: str, drone_type: str):
    """Insert a new drone and log commissioning. Returns inserted drone_id."""
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO drones (call_sign, drone_type, status) VALUES (?, ?, ?)",
            (call_sign, drone_type, 'IDLE')
        )
        drone_id = cur.lastrowid
        conn.commit()
        log_mission_entry(drone_id, f"Drone {call_sign} commissioned as {drone_type}.")
        return drone_id
    except sqlite3.IntegrityError as e:
        raise ValueError(f"Could not add drone: {e}")


def add_planet(name: str, environment: str, resource_level: int):
    """Insert a new planet. Returns planet_id."""
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO planets (name, environment, resource_level) VALUES (?, ?, ?)",
            (name, environment, int(resource_level))
        )
        planet_id = cur.lastrowid
        conn.commit()
        return planet_id
    except sqlite3.IntegrityError as e:
        raise ValueError(f"Could not add planet: {e}")


def delete_drone(drone_id: int):
    """Delete a drone by id."""
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM drones WHERE drone_id = ?", (drone_id,))
    conn.commit()


def delete_planet(planet_id: int):
    """Delete a planet by id."""
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM planets WHERE planet_id = ?", (planet_id,))
    conn.commit()


def deploy_drone_to_planet(drone_id: int, planet_id: int, duration_in_minutes: int, mission_name: str):
    """Assign a drone to a mission on a planet."""
    conn = get_db_connection()
    cur = conn.cursor()
    # Validate statuses
    cur.execute("SELECT * FROM drones WHERE drone_id = ?", (drone_id,))
    row = cur.fetchone()
    if not row:
        raise ValueError("Drone not found")
    row = dict(zip([col[0] for col in cur.description], row))  # convert tuple to dict
    if row['status'] != 'IDLE':
        raise ValueError("Drone not IDLE")

    cur.execute("SELECT * FROM planets WHERE planet_id = ?", (planet_id,))
    prow = cur.fetchone()
    if not prow:
        raise ValueError("Planet not found")

    cur.execute(
        "UPDATE drones SET status=?, current_planet_id=?, mission_name=?, mission_status=?, mission_total_turns=?, mission_turns_remaining=? WHERE drone_id=?",
        ('ACTIVE', planet_id, mission_name, 'ACTIVE', int(duration_in_minutes), int(duration_in_minutes), drone_id)
    )
    conn.commit()
    log_mission_entry(drone_id, f"Deployed on mission '{mission_name}' to planet_id {planet_id} for {duration_in_minutes} minutes.")

def update_drone(drone_object: dict):
    """Save a drone record (dict with keys matching columns)."""
    conn = get_db_connection()
    cur = conn.cursor()
    keys = [
        'call_sign','drone_type','status','mission_name','mission_status',
        'current_planet_id','cargo','mission_total_turns','mission_turns_remaining'
    ]
    set_clause = ", ".join([f"{k} = ?" for k in keys])
    values = [drone_object.get(k) for k in keys]
    values.append(drone_object['drone_id'])
    cur.execute(f"UPDATE drones SET {set_clause} WHERE drone_id = ?", values)
    conn.commit()


def get_all_drones():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM drones")
    rows = cur.fetchall()
    return [dict(zip([col[0] for col in cur.description], row)) for row in rows]



def get_drones_by_status(status: str):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM drones WHERE status = ?", (status,))
    rows = cur.fetchall()
    return [dict(zip([col[0] for col in cur.description], row)) for row in rows]


def get_drones_by_mission_status(mission_status: str):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM drones WHERE mission_status = ?", (mission_status,))
    rows = cur.fetchall()
    return [dict(zip([col[0] for col in cur.description], row)) for row in rows]



def get_all_planets():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM planets")
    rows = cur.fetchall()
    return [dict(zip([col[0] for col in cur.description], row)) for row in rows]


def get_planet_by_id(planet_id: int):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM planets WHERE planet_id = ?", (planet_id,))
    row = cur.fetchone()
    return dict(zip([col[0] for col in cur.description], row)) if row else None



def get_drone_by_mission_name(mission_name: str):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM drones WHERE mission_name = ?", (mission_name,))
    row = cur.fetchone()
    return dict(zip([col[0] for col in cur.description], row)) if row else None


def log_mission_entry(drone_id: int, entry: str):
    """Add an entry to the mission log with a timestamp."""
    conn = get_db_connection()
    cur = conn.cursor()
    ts = datetime.utcnow().isoformat() + 'Z'
    cur.execute(
        "INSERT INTO mission_log (drone_id, timestamp, log_entry) VALUES (?, ?, ?)",
        (drone_id, ts, entry)
    )
    conn.commit()


def get_log_for_drone(drone_id: int):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM mission_log WHERE drone_id = ? ORDER BY log_id ASC", (drone_id,))
    rows = cur.fetchall()
    return [dict(zip([col[0] for col in cur.description], row)) for row in rows]