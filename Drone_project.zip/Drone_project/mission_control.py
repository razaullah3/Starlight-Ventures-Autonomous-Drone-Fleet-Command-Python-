import threading
import time
import random
from database import get_drones_by_mission_status, get_planet_by_id, log_mission_entry
from models import get_drone_object

simulation_running = False
_sim_thread = None
TICK_INTERVAL = 5  # testing کے لیے 5 سیکنڈ رکھا ہے


def _process_minute_for_drone(drone_record):
    drone_obj = get_drone_object(drone_record)
    if drone_obj.mission_turns_remaining is None:
        return

    # ہر tick پر mission turn کم کرو
    drone_obj.mission_turns_remaining -= 1
    drone_obj._log_activity(
        f"{drone_obj.call_sign} mission time decremented to {drone_obj.mission_turns_remaining}."
    )

    # اگر mission time ختم ہو گیا تو complete کر دو
    if drone_obj.mission_turns_remaining <= 0:
        planet = get_planet_by_id(drone_obj.current_planet_id)
        if planet:
            drone_obj.perform_mission(planet)
        else:
            drone_obj.mission_status = 'COMPLETED'
            drone_obj.status = 'IDLE'
            drone_obj._log_activity(f"{drone_obj.call_sign} completed mission but planet missing.")
            drone_obj.mission_name = None
            drone_obj.mission_total_turns = None
            drone_obj.mission_turns_remaining = None
            drone_obj._update_database_record()
    else:
        drone_obj._update_database_record()


def advance_time_for_fleet():
    active = get_drones_by_mission_status('ACTIVE')
    if not active:
        return
    for rec in active:
        try:
            _process_minute_for_drone(rec)
        except Exception as e:
            log_mission_entry(rec.get('drone_id'), f"Error during simulation tick: {e}")


def simulation_loop():
    global simulation_running
    while simulation_running:
        advance_time_for_fleet()
        time.sleep(TICK_INTERVAL)


def start_simulation():
    global simulation_running, _sim_thread
    if simulation_running:
        return
    simulation_running = True
    _sim_thread = threading.Thread(target=simulation_loop, daemon=True)
    _sim_thread.start()


def stop_simulation():
    global simulation_running, _sim_thread
    simulation_running = False
    if _sim_thread:
        _sim_thread.join(timeout=2)