import os
BASE_DIR = os.path.dirname(__file__)
# now_directory = os.getcwd()
print(BASE_DIR)