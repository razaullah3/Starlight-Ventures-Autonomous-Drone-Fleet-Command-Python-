"""
main.py
Command-line interface for the Starlight Command application.
"""
import os
from database import create_tables, add_drone, add_planet, delete_drone, delete_planet, deploy_drone_to_planet, get_all_drones, get_all_planets, get_drones_by_mission_status, get_log_for_drone, get_drone_by_mission_name, close_db_connection
from mission_control import start_simulation, stop_simulation


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


def prompt_enter():
    input('\nPress Enter to continue...')


# --- Menus ---

def fleet_management_menu():
    while True:
        clear_screen()
        print('--- Fleet Management ---')
        print('1. Add Drone')
        print('2. View Drones')
        print('3. Delete Drone')
        print('4. Back')
        choice = input('Choice: ').strip()
        if choice == '1':
            cs = input('Call sign: ').strip()
            dtype = input('Type (Mining/Science/Scout): ').strip()
            try:
                did = add_drone(cs, dtype)
                print(f'Drone added with id: {did}')
            except Exception as e:
                print('Error:', e)
            prompt_enter()
        elif choice == '2':
            drones = get_all_drones()
            if not drones:
                print('No drones found.')
            else:
                for d in drones:
                    print(d)
            prompt_enter()
        elif choice == '3':
            try:
                did = int(input('Drone ID to delete: ').strip())
                delete_drone(did)
                print('Deleted if existed.')
            except ValueError:
                print('Invalid ID.')
            prompt_enter()
        elif choice == '4':
            return
        else:
            print('Invalid choice')
            prompt_enter()


def planet_db_menu():
    while True:
        clear_screen()
        print('--- Planet Database ---')
        print('1. Add Planet')
        print('2. View Planets')
        print('3. Delete Planet')
        print('4. Back')
        choice = input('Choice: ').strip()
        if choice == '1':
            name = input('Name: ').strip()
            env = input('Environment: ').strip()
            try:
                rl = int(input('Resource level: ').strip())
                pid = add_planet(name, env, rl)
                print('Planet added id', pid)
            except ValueError:
                print('Invalid resource level or duplicate name.')
            prompt_enter()
        elif choice == '2':
            planets = get_all_planets()
            if not planets:
                print('No planets found.')
            else:
                for p in planets:
                    print(p)
            prompt_enter()
        elif choice == '3':
            try:
                pid = int(input('Planet ID to delete: ').strip())
                delete_planet(pid)
                print('Deleted if existed.')
            except ValueError:
                print('Invalid ID.')
            prompt_enter()
        elif choice == '4':
            return
        else:
            print('Invalid choice')
            prompt_enter()


def deploy_menu():
    clear_screen()
    print('--- Deploy Drone on Mission ---')
    try:
        drones = get_all_drones()
        idle = [d for d in drones if d.get('status') == 'IDLE']
        if not idle:
            print('No idle drones available')
            prompt_enter()
            return
        for d in idle:
            print(d['drone_id'], d['call_sign'], d['drone_type'])
        did = int(input('Drone ID: ').strip())
        planets = get_all_planets()
        if not planets:
            print('No planets available.')
            prompt_enter()
            return
        for p in planets:
            print(p['planet_id'], p['name'], p['environment'], p['resource_level'])
        pid = int(input('Planet ID: ').strip())
        mname = input('Mission name: ').strip()
        duration = int(input('Duration (minutes): ').strip())
        deploy_drone_to_planet(did, pid, duration, mname)
        print('Mission deployed.')
    except Exception as e:
        print('Error deploying mission:', e)
    prompt_enter()


def view_missions_menu():
    clear_screen()
    f = input('Filter by mission status (ACTIVE/COMPLETED/CANCELLED/ALL): ').strip().upper() or 'ALL'
    if f == 'ALL':
        drones = get_all_drones()
    else:
        drones = get_drones_by_mission_status(f)
    if not drones:
        print('No missions found.')
    else:
        for d in drones:
            print(d)
    prompt_enter()


def view_mission_log_menu():
    clear_screen()
    f = input('Filter (ACTIVE/COMPLETED/CANCELLED/ALL): ').strip().upper() or 'ALL'
    drones = get_all_drones() if f == 'ALL' else get_drones_by_mission_status(f)
    if not drones:
        print('No missions to show.')
        prompt_enter()
        return
    for d in drones:
        print(f"ID:{d['drone_id']} Call:{d['call_sign']} Mission:{d.get('mission_name')} Status:{d.get('mission_status')}")
    try:
        did = int(input('Enter Drone ID to view log (0 to cancel): ').strip())
        if did == 0:
            return
        logs = get_log_for_drone(did)
        for l in logs:
            print(f"{l['timestamp']}: {l['log_entry']}")
    except ValueError:
        print('Invalid input.')
    prompt_enter()


def cancel_mission_menu():
    clear_screen()
    try:
        mname = input('Mission name to cancel: ').strip()
        rec = get_drone_by_mission_name(mname)
        if not rec:
            print('Mission not found')
        else:
            from models import get_drone_object
            obj = get_drone_object(rec)
            obj.abort_mission()
            print('Mission aborted.')
    except Exception as e:
        print('Error:', e)
    prompt_enter()


def main_loop():
    create_tables()
    start_simulation()
    try:
        while True:
            clear_screen()
            print('=== Starlight Ventures Drone Command ===')
            print('1. Fleet Management')
            print('2. Planet Database')
            print('3. Deploy Drone on Mission')
            print('4. View All Missions')
            print('5. View Mission Log')
            print('6. Cancel Mission')
            print('7. Exit')
            ch = input('Choice: ').strip()
            if ch == '1':
                fleet_management_menu()
            elif ch == '2':
                planet_db_menu()
            elif ch == '3':
                deploy_menu()
            elif ch == '4':
                view_missions_menu()
            elif ch == '5':
                view_mission_log_menu()
            elif ch == '6':
                cancel_mission_menu()
            elif ch == '7':
                print('Exiting...')
                break
            elif ch.upper() == 'X':
                exit()

            else:
                print('Invalid choice')
                prompt_enter()
    finally:
        stop_simulation()
        close_db_connection()


if __name__ == '__main__':
    main_loop()