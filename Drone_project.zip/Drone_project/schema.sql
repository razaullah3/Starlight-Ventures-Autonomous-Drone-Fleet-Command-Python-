-- schema.sql
PRAGMA foreign_keys = ON;


CREATE TABLE IF NOT EXISTS planets (
planet_id INTEGER PRIMARY KEY,
name TEXT UNIQUE NOT NULL,
environment TEXT NOT NULL,
resource_level INTEGER NOT NULL
);


CREATE TABLE IF NOT EXISTS drones (
drone_id INTEGER PRIMARY KEY,
call_sign TEXT UNIQUE NOT NULL,
drone_type TEXT NOT NULL,
status TEXT NOT NULL,
mission_name TEXT,
mission_status TEXT,
current_planet_id INTEGER,
cargo TEXT,
mission_total_turns INTEGER,
mission_turns_remaining INTEGER,
FOREIGN KEY(current_planet_id) REFERENCES planets(planet_id) ON DELETE SET NULL
);


CREATE TABLE IF NOT EXISTS mission_log (
log_id INTEGER PRIMARY KEY,
drone_id INTEGER NOT NULL,
timestamp TEXT NOT NULL,
log_entry TEXT NOT NULL,
FOREIGN KEY(drone_id) REFERENCES drones(drone_id) ON DELETE CASCADE
);