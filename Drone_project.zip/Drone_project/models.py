"""
models.py
Defines Drone classes and helper to map DB records to objects.
"""
from abc import ABC, abstractmethod
from database import log_mission_entry, update_drone


class Drone(ABC):
    """Abstract base Drone class."""
    def __init__(self, drone_id, call_sign, drone_type, status, current_planet_id=None,
                 cargo=None, mission_total_turns=None, mission_turns_remaining=None,
                 mission_name=None, mission_status=None):
        self.drone_id = drone_id
        self.call_sign = call_sign
        self.drone_type = drone_type
        self.status = status
        self.current_planet_id = current_planet_id
        self.cargo = cargo
        self.mission_total_turns = mission_total_turns
        self.mission_turns_remaining = mission_turns_remaining
        self.mission_name = mission_name
        self.mission_status = mission_status

    @abstractmethod
    def perform_mission(self, planet_object):
        pass

    def take_damage(self):
        self.status = 'MAINTENANCE'
        log_mission_entry(self.drone_id, f"{self.call_sign} damaged and sent to MAINTENANCE.")
        self._update_database_record()

    def abort_mission(self):
        self.mission_status = 'CANCELLED'
        self.status = 'IDLE'
        log_mission_entry(self.drone_id, f"Mission '{self.mission_name}' aborted for {self.call_sign}.")
        self.mission_name = None
        self.mission_total_turns = None
        self.mission_turns_remaining = None
        self.current_planet_id = None
        self._update_database_record()

    def _log_activity(self, entry: str):
        log_mission_entry(self.drone_id, entry)

    def _update_database_record(self):
        record = {
            'drone_id': self.drone_id,
            'call_sign': self.call_sign,
            'drone_type': self.drone_type,
            'status': self.status,
            'mission_name': self.mission_name,
            'mission_status': self.mission_status,
            'current_planet_id': self.current_planet_id,
            'cargo': self.cargo,
            'mission_total_turns': self.mission_total_turns,
            'mission_turns_remaining': self.mission_turns_remaining
        }
        update_drone(record)


class MiningDrone(Drone):
    def perform_mission(self, planet_object):
        amount = max(1, int(planet_object['resource_level'] * 0.1))
        self.cargo = f"Ore:{amount}"
        self.status = 'IDLE'
        self.mission_status = 'COMPLETED'
        self._log_activity(f"{self.call_sign} extracted {self.cargo} from {planet_object['name']}")
        self.current_planet_id = planet_object['planet_id']
        self.mission_name = None
        self.mission_total_turns = None
        self.mission_turns_remaining = None
        self._update_database_record()


class ScienceDrone(Drone):
    def perform_mission(self, planet_object):
        self.cargo = f"Data:{planet_object['environment']}"
        self.status = 'IDLE'
        self.mission_status = 'COMPLETED'
        self._log_activity(f"{self.call_sign} gathered science data from {planet_object['name']}")
        self.current_planet_id = planet_object['planet_id']
        self.mission_name = None
        self.mission_total_turns = None
        self.mission_turns_remaining = None
        self._update_database_record()


class ScoutDrone(Drone):
    def perform_mission(self, planet_object):
        self.cargo = None
        self.status = 'IDLE'
        self.mission_status = 'COMPLETED'
        self._log_activity(f"{self.call_sign} scouted {planet_object['name']} ({planet_object['environment']})")
        self.current_planet_id = planet_object['planet_id']
        self.mission_name = None
        self.mission_total_turns = None
        self.mission_turns_remaining = None
        self._update_database_record()


def get_drone_object(drone_record: dict) -> Drone:
    """Factory: return the right Drone subclass instance given a DB record dict."""
    dtype = drone_record.get('drone_type')
    if dtype == 'Mining':
        cls = MiningDrone
    elif dtype == 'Science':
        cls = ScienceDrone
    else:
        cls = ScoutDrone

    return cls(
        drone_id=drone_record.get('drone_id'),
        call_sign=drone_record.get('call_sign'),
        drone_type=drone_record.get('drone_type'),
        status=drone_record.get('status'),
        current_planet_id=drone_record.get('current_planet_id'),
        cargo=drone_record.get('cargo'),
        mission_total_turns=drone_record.get('mission_total_turns'),
        mission_turns_remaining=drone_record.get('mission_turns_remaining'),
        mission_name=drone_record.get('mission_name'),
        mission_status=drone_record.get('mission_status')
    )